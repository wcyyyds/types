import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FileEntity } from './entities/file.entity';
import { UploadSessionEntity, UploadChunkEntity } from './entities/upload-chunk.entity';
import { FileResponseDto } from './dto/upload.dto';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

@Injectable()
export class UnifiedUploadService {
  private readonly uploadPath = 'uploads';
  private readonly chunkPath = 'uploads/chunks';
  private readonly maxFileSize = 10 * 1024 * 1024; // 10MB 小文件阈值
  private readonly maxChunkSize = 5 * 1024 * 1024; // 5MB 分片大小
  private readonly maxTotalSize = 2 * 1024 * 1024 * 1024; // 2GB 总大小限制

  constructor(
    @InjectRepository(FileEntity)
    private fileRepository: Repository<FileEntity>,
    @InjectRepository(UploadSessionEntity)
    private uploadSessionRepository: Repository<UploadSessionEntity>,
    @InjectRepository(UploadChunkEntity)
    private uploadChunkRepository: Repository<UploadChunkEntity>,
  ) {
    this.ensureDirectories();
  }

  private ensureDirectories() {
    [this.uploadPath, this.chunkPath].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
  }

  private generateUserFileName(userId: number): string {
    const uuid = crypto.randomUUID();
    return `${userId}-${uuid}`;
  }

  private calculateFileHash(buffer: Buffer): string {
    return crypto.createHash('md5').update(buffer).digest('hex');
  }

  private getMimeType(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const mimeTypes = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
      '.pdf': 'application/pdf',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.txt': 'text/plain',
      '.zip': 'application/zip',
    };
    return mimeTypes[ext] || 'application/octet-stream';
  }

  // 统一上传接口 - 简化版本
  async uploadFiles(
    files: Express.Multer.File[],
    userId: number,
    category?: string,
    description?: string,
  ): Promise<{
    sessionId: string;
    results: Array<{
      originalName: string;
      size: number;
      type: 'small' | 'large';
      status: 'success' | 'failed';
      result?: FileResponseDto;
      error?: string;
    }>;
  }> {
    if (!files || files.length === 0) {
      throw new BadRequestException('请选择要上传的文件');
    }

    if (!userId) {
      throw new BadRequestException('用户ID不能为空');
    }

    const sessionId = crypto.randomUUID();
    const results = [];

    // 处理每个文件
    for (const file of files) {
      const isLarge = file.size > this.maxFileSize;
      
      try {
        if (isLarge) {
          // 大文件：分片上传
          const result = await this.processLargeFile(file, userId, category, description);
          results.push({
            originalName: file.originalname,
            size: file.size,
            type: 'large',
            status: 'success',
            result,
          });
        } else {
          // 小文件：直接上传
          const result = await this.processSmallFile(file, userId, category, description);
          results.push({
            originalName: file.originalname,
            size: file.size,
            type: 'small',
            status: 'success',
            result,
          });
        }
      } catch (error) {
        results.push({
          originalName: file.originalname,
          size: file.size,
          type: isLarge ? 'large' : 'small',
          status: 'failed',
          error: error.message,
        });
      }
    }

    return {
      sessionId,
      results,
    };
  }

  // 处理小文件
  private async processSmallFile(
    file: Express.Multer.File,
    userId: number,
    category?: string,
    description?: string,
  ): Promise<FileResponseDto> {
    // 生成文件名
    const baseFilename = this.generateUserFileName(userId);
    const extension = path.extname(file.originalname);
    const filename = baseFilename + extension;
    const filePath = path.join(this.uploadPath, filename);

    // 保存文件
    fs.writeFileSync(filePath, file.buffer);

    // 保存到数据库
    const fileEntity = this.fileRepository.create({
      originalName: file.originalname,
      filename,
      path: filePath,
      mimetype: file.mimetype,
      size: file.size,
      category: category || 'others',
      description,
      uploadedBy: userId,
    });

    const savedFile = await this.fileRepository.save(fileEntity);
    return this.mapToResponseDto(savedFile);
  }

  // 处理大文件
  private async processLargeFile(
    file: Express.Multer.File,
    userId: number,
    category?: string,
    description?: string,
  ): Promise<FileResponseDto> {
    // 创建上传会话
    const uploadId = crypto.randomUUID();
    const totalChunks = Math.ceil(file.size / this.maxChunkSize);
    const fileHash = this.calculateFileHash(file.buffer);

    const session = this.uploadSessionRepository.create({
      uploadId,
      originalName: file.originalname,
      totalSize: file.size,
      totalChunks,
      fileHash,
      category: category || 'others',
      description,
      uploadedBy: userId,
      status: 'uploading',
    });

    await this.uploadSessionRepository.save(session);

    // 分片处理
    await this.processFileChunks(file, uploadId, totalChunks);

    // 合并分片
    const finalPath = await this.mergeChunks(uploadId, userId, file.originalname);

    // 创建文件记录
    const fileEntity = this.fileRepository.create({
      originalName: file.originalname,
      filename: path.basename(finalPath),
      path: finalPath,
      mimetype: file.mimetype,
      size: file.size,
      category: category || 'others',
      description,
      uploadedBy: userId,
    });

    const savedFile = await this.fileRepository.save(fileEntity);

    // 更新会话状态
    session.status = 'completed';
    session.finalPath = finalPath;
    session.fileId = savedFile.id;
    session.completedAt = new Date();
    await this.uploadSessionRepository.save(session);

    return this.mapToResponseDto(savedFile);
  }

  // 处理文件分片
  private async processFileChunks(
    file: Express.Multer.File,
    uploadId: string,
    totalChunks: number,
  ) {
    const buffer = file.buffer;
    const chunkSize = this.maxChunkSize;

    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkSize;
      const end = Math.min(start + chunkSize, buffer.length);
      const chunkBuffer = buffer.slice(start, end);

      const chunkPath = path.join(this.chunkPath, `${uploadId}_${i}`);
      fs.writeFileSync(chunkPath, chunkBuffer);

      const chunk = this.uploadChunkRepository.create({
        uploadId,
        chunkNumber: i,
        chunkPath,
        chunkSize: chunkBuffer.length,
        chunkHash: this.calculateFileHash(chunkBuffer),
        isUploaded: true,
      });

      await this.uploadChunkRepository.save(chunk);
    }
  }

  // 合并分片
  private async mergeChunks(uploadId: string, userId: number, originalName: string): Promise<string> {
    const chunks = await this.uploadChunkRepository.find({
      where: { uploadId },
      order: { chunkNumber: 'ASC' },
    });

    const baseFilename = this.generateUserFileName(userId);
    const extension = path.extname(originalName);
    const filename = baseFilename + extension;
    const finalPath = path.join(this.uploadPath, filename);

    const writeStream = fs.createWriteStream(finalPath);

    for (const chunk of chunks) {
      const chunkBuffer = fs.readFileSync(chunk.chunkPath);
      writeStream.write(chunkBuffer);
    }

    writeStream.end();

    // 等待写入完成
    await new Promise((resolve, reject) => {
      writeStream.on('finish', ()=>resolve);
      writeStream.on('error', reject);
    });

    // 清理分片文件
    for (const chunk of chunks) {
      if (fs.existsSync(chunk.chunkPath)) {
        fs.unlinkSync(chunk.chunkPath);
      }
    }

    await this.uploadChunkRepository.delete({ uploadId });

    return finalPath;
  }


  // 映射到响应DTO
  private mapToResponseDto(file: FileEntity): FileResponseDto {
    return {
      id: file.id,
      originalName: file.originalName,
      filename: file.filename,
      path: file.path,
      mimetype: file.mimetype,
      size: file.size,
      category: file.category,
      description: file.description,
      uploadedBy: file.uploadedBy,
      createdAt: file.createdAt,
      updatedAt: file.updatedAt,
      url: `/upload/files/${file.id}/download`,
    };
  }
}
