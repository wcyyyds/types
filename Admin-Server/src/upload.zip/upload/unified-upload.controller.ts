import {
  Controller,
  Post,
  Query,
  UseInterceptors,
  UploadedFiles,
  BadRequestException,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { UnifiedUploadService } from './unified-upload.service';

@Controller('upload')
export class UnifiedUploadController {
  constructor(private readonly unifiedUploadService: UnifiedUploadService) {}

  // 统一上传接口
  @Post('unified')
  @UseInterceptors(FilesInterceptor('files', 20)) // 最多20个文件
  async uploadFiles(
    @UploadedFiles() files: Express.Multer.File[],
    @Query('userId') userId: string,
    @Query('category') category?: string,
    @Query('description') description?: string,
  ) {
    if (!files || files.length === 0) {
      throw new BadRequestException('请选择要上传的文件');
    }

    if (!userId) {
      throw new BadRequestException('用户ID不能为空');
    }

    const userIdNum = parseInt(userId, 10);
    if (isNaN(userIdNum)) {
      throw new BadRequestException('用户ID格式不正确');
    }

    return await this.unifiedUploadService.uploadFiles(
      files,
      userIdNum,
      category,
      description,
    );
  }

}
