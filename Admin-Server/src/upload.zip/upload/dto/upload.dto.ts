import { IsOptional, IsString, IsNumber, MaxLength } from 'class-validator';

export class UploadFileDto {
  @IsOptional()
  @IsString()
  @MaxLength(50)
  category?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;
}

export class FileResponseDto {
  id: number;
  originalName: string;
  filename: string;
  path: string;
  mimetype: string;
  size: number;
  category?: string;
  description?: string;
  uploadedBy?: number;
  createdAt: Date;
  updatedAt: Date;
  url: string;
}
