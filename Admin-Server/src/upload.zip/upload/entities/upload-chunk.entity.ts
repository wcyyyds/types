import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, Index } from 'typeorm';

@Entity('upload_chunks')
@Index(['uploadId', 'chunkNumber'], { unique: true })
export class UploadChunkEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  uploadId: string;              // 上传会话ID

  @Column()
  chunkNumber: number;           // 分片序号

  @Column({ length: 500 })
  chunkPath: string;            // 分片文件路径

  @Column('bigint')
  chunkSize: number;            // 分片大小

  @Column({ length: 100 })
  chunkHash: string;            // 分片哈希值

  @Column({ default: false })
  isUploaded: boolean;          // 是否已上传

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('upload_sessions')
export class UploadSessionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100, unique: true })
  uploadId: string;             // 上传会话ID

  @Column({ length: 255 })
  originalName: string;         // 原始文件名

  @Column('bigint')
  totalSize: number;            // 总文件大小

  @Column()
  totalChunks: number;         // 总分片数

  @Column({ default: 0 })
  uploadedChunks: number;      // 已上传分片数

  @Column({ length: 100 })
  fileHash: string;            // 文件哈希值

  @Column({ length: 50 })
  category: string;             // 文件分类

  @Column({ length: 500, nullable: true })
  description: string;          // 文件描述

  @Column({ nullable: true })
  uploadedBy: number;           // 上传者用户ID

  @Column({ default: 'uploading' })
  status: string;               // 状态: uploading, completed, failed

  @Column({ length: 500, nullable: true })
  finalPath: string;            // 最终文件路径

  @Column({ nullable: true })
  fileId: number;              // 关联的文件ID

  @CreateDateColumn()
  createdAt: Date;

  @Column({ nullable: true })
  completedAt: Date;
}
