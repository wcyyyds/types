import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UnifiedUploadController } from './unified-upload.controller';
import { UnifiedUploadService } from './unified-upload.service';
import { FileEntity } from './entities/file.entity';
import { UploadSessionEntity, UploadChunkEntity } from './entities/upload-chunk.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FileEntity,
      UploadSessionEntity,
      UploadChunkEntity,
    ]),
  ],
  controllers: [UnifiedUploadController],
  providers: [UnifiedUploadService],
  exports: [UnifiedUploadService],
})
export class UploadModule {}
